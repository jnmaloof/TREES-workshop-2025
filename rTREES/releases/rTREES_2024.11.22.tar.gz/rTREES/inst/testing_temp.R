library(rTREES)
library(tictoc)
library(tidyverse)
options(scipen=99999)


# # df_test<-data.table::fread("inst/FP_ex/FP_driver.txt",data.table = F)
# # ex_driver<-ExampleDriver(precip_amount = 100,start_jday =300,precipdays = 300:305,ndays=5)
# test<-ExampleParameters()
test_fp<-Load_TREES_files(
  # driver="inst/FP_ex/FP_driver.txt",
  # parameters = "inst/FP_ex/FP_parameter.p",
  # ,root_shoot_soil = "inst/FP_ex/FP_param_mod"
  driver="~/paper_share/Research_Web_Log/main_site/.data/FP_Static/FP_Driver_EX.txt",
  parameters = "~/paper_share/Research_Web_Log/main_site/.data/FP_Static/FP_parameter.p",
  ,root_shoot_soil = "~/paper_share/Research_Web_Log/main_site/.data/FP_Static/FP_param_mod"
)
timeout_calibration<-function(driver,parameters,rss){
driver=test_fp$driver
parameters=test_fp$parameters
rss=test_fp$root_shoot_soil
res<- rTREES(driver[1:778,],parameters,rss,c(T,T,T),verbosity = F)

  message("Begining calibration, ignore print out until complete.")
  ncores<-future::availableCores()-2
  all_toc<-vector()
  calib_max<-nrow(driver)
  calib_steps<-c(
    calib_max,
    floor(calib_max*0.9),
    floor(calib_max*0.8),
    floor(calib_max*0.7),
    floor(calib_max*0.6),
    floor(calib_max*0.5),
    floor(calib_max*0.4),
    floor(calib_max*0.3),
    floor(calib_max*0.2),
    floor(calib_max*0.1)
  )
  if(any(calib_steps<3)){
    calib_steps[which(calib_steps<3)]<-rep(3,sum(which(calib_steps<3)))
  }
  newp<-data.frame(
    altitude=rnorm(1,parameters[1,1],parameters[1,1]*0.25)
  )
  i=1
  tic()
  temp_dr<-driver[1:calib_steps[i],]
  dump<-rTREES_parallel_run(
    base_parameters = parameters,
    drivers=driver[1:702,],
    root_shoot_soil = rss,
    new_parameters = newp,
    vars_to_return = "all",
    interval_to_return = 0.5,
    aggregate_time_steps = F,
    verbosity =F
  )
  temptoc=toc()
  all_toc[i]=temptoc$toc-temptoc$tic

 res<- rTREES(driver[1:777,],parameters,rss,c(T,T,T),verbosity = F)

  i=i+1
  tic()
  temp_dr<-driver[1:calib_steps[i],]
  options(future.globals.onReference = NULL)
  dump2<-rTREES_parallel_run_test(
    base_parameters = parameters,
    drivers=list(test_fp$driver[1:777,]),
    root_shoot_soil = rss,
    new_parameters =newp ,
    vars_to_return = "all",
    interval_to_return = 0.5,
    aggregate_time_steps = F,
    verbosity =F,ncores = 1
  )
  temptoc=toc()
  all_toc[i]=temptoc$toc-temptoc$tic

  i=i+1
  tic()
  temp_dr<-driver[1:calib_steps[i],]
  dump<-rTREES_parallel_run(
    base_parameters = parameters,
    drivers=temp_dr,
    root_shoot_soil = rss,
    new_parameters = data.frame(
      altitude=rnorm(ncores,parameters[1,1],parameters[1,1]*0.25)
    ),
    vars_to_return = "all",
    interval_to_return = 0.5,
    aggregate_time_steps = F,
    verbosity =F
  )
  temptoc=toc()
  all_toc[i]=temptoc$toc-temptoc$tic

  i=i+1
  tic()
  temp_dr<-driver[1:calib_steps[i],]
  dump<-rTREES_parallel_run(
    base_parameters = parameters,
    drivers=temp_dr,
    root_shoot_soil = rss,
    new_parameters = data.frame(
      altitude=rnorm(ncores,parameters[1,1],parameters[1,1]*0.25)
    ),
    vars_to_return = "all",
    interval_to_return = 0.5,
    aggregate_time_steps = F,
    verbosity =F
  )
  temptoc=toc()
  all_toc[i]=temptoc$toc-temptoc$tic

  i=i+1
  tic()
  temp_dr<-driver[1:calib_steps[i],]
  dump<-rTREES_parallel_run(
    base_parameters = parameters,
    drivers=temp_dr,
    root_shoot_soil = rss,
    new_parameters = data.frame(
      altitude=rnorm(ncores,parameters[1,1],parameters[1,1]*0.25)
    ),
    vars_to_return = "all",
    interval_to_return = 0.5,
    aggregate_time_steps = F,
    verbosity =F
  )
  temptoc=toc()
  all_toc[i]=temptoc$toc-temptoc$tic

  i=i+1
  tic()
  temp_dr<-driver[1:calib_steps[i],]
  dump<-rTREES_parallel_run(
    base_parameters = parameters,
    drivers=temp_dr,
    root_shoot_soil = rss,
    new_parameters = data.frame(
      altitude=rnorm(ncores,parameters[1,1],parameters[1,1]*0.25)
    ),
    vars_to_return = "all",
    interval_to_return = 0.5,
    aggregate_time_steps = F,
    verbosity =F
  )
  temptoc=toc()
  all_toc[i]=temptoc$toc-temptoc$tic

  i=i+1
  tic()
  temp_dr<-driver[1:calib_steps[i],]
  dump<-rTREES_parallel_run(
    base_parameters = parameters,
    drivers=temp_dr,
    root_shoot_soil = rss,
    new_parameters = data.frame(
      altitude=rnorm(ncores,parameters[1,1],parameters[1,1]*0.25)
    ),
    vars_to_return = "all",
    interval_to_return = 0.5,
    aggregate_time_steps = F,
    verbosity =F
  )
  temptoc=toc()
  all_toc[i]=temptoc$toc-temptoc$tic

  i=i+1
  tic()
  temp_dr<-driver[1:calib_steps[i],]
  dump<-rTREES_parallel_run(
    base_parameters = parameters,
    drivers=temp_dr,
    root_shoot_soil = rss,
    new_parameters = data.frame(
      altitude=rnorm(ncores,parameters[1,1],parameters[1,1]*0.25)
    ),
    vars_to_return = "all",
    interval_to_return = 0.5,
    aggregate_time_steps = F,
    verbosity =F
  )
  temptoc=toc()
  all_toc[i]=temptoc$toc-temptoc$tic

  i=i+1
  tic()
  temp_dr<-driver[1:calib_steps[i],]
  dump<-rTREES_parallel_run(
    base_parameters = parameters,
    drivers=temp_dr,
    root_shoot_soil = rss,
    new_parameters = data.frame(
      altitude=rnorm(ncores,parameters[1,1],parameters[1,1]*0.25)
    ),
    vars_to_return = "all",
    interval_to_return = 0.5,
    aggregate_time_steps = F,
    verbosity =F
  )
  temptoc=toc()
  all_toc[i]=temptoc$toc-temptoc$tic

  i=i+1
  tic()
  temp_dr<-driver[1:calib_steps[i],]
  dump<-rTREES_parallel_run(
    base_parameters = parameters,
    drivers=temp_dr,
    root_shoot_soil = rss,
    new_parameters = data.frame(
      altitude=rnorm(ncores,parameters[1,1],parameters[1,1]*0.25)
    ),
    vars_to_return = "all",
    interval_to_return = 0.5,
    aggregate_time_steps = F,
    verbosity =F
  )
  temptoc=toc()
  all_toc[i]=temptoc$toc-temptoc$tic


  coefs<-lm(all_toc~calib_steps)
  return(as.vector(coefs$coefficients))
}

timeout_calibration(test_fp$driver,test_fp$parameters,test_fp$root_shoot_soil)

library(rTREES)
library(tictoc)
library(tidyverse)
options(scipen=99999)


test_fp<-Load_TREES_files(
  driver="~/paper_share/Research_Web_Log/main_site/.data/FP_Static/FP_Driver_EX.txt",
  parameters = "~/paper_share/Research_Web_Log/main_site/.data/FP_Static/FP_parameter.p",
  ,root_shoot_soil = "~/paper_share/Research_Web_Log/main_site/.data/FP_Static/FP_param_mod"
)

driver=test_fp$driver
parameters=test_fp$parameters
rss=test_fp$root_shoot_soil

res<-TEST_func(
  d_in=driver[1:3,],
  # r_in=rss,
  # p_in=parameters,
  # w_out=c(T,T,T),
  verbosity = F
)



res<-TEST_func(
  d_in=driver[1:3,],
  # r_in=rss,
  # p_in=parameters,
  # w_out=c(T,T,T),
  verbosity = F
)

results<-vector()
for(i in 1:1000){
  withCallingHandlers({
    setTimeLimit(time_limit);
    results[i]<-long_function(i)
  },
  warning = function(w) {
    results[i]<-i
  }
  )
}
