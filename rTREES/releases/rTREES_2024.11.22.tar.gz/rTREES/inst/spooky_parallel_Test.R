#' Get the max depth of a list. Adopted from https://stackoverflow.com/questions/13432863/determine-level-of-nesting-in-r#comment18364266_13433689
#' @param this the list of interest
#' @return Maximum depth of list as an integer.
#' @export
depth <- function(this){
  ifelse(is.list(this), 1L + max(sapply(this, depth)), 0L)
}

#' @import progressr
#' @import callr
#' @param base_parameters Initial parameters. Using Load_TREES_files() is recommended
#' @param drivers Environmental driver. Using Load_TREES_files() is recommended
#' @param rss Initial root_shoot_soil. Using Load_TREES_files() is recommended
#' @param new_parameters Parameters to be run. rTREES will be run over each row.
#' @param n_cores The number of cores you would like jobs to be split among. It is recommended that you keep a couple cores free for your system to retain functionality while running simulations.
#' @param which_out vector of bool for returning sim,hyd, and/or leaf outputs
#' @param vars_to_return rTREES outputs you want to have returned. Using 'all' is allowed but not recommend. See Possible_vars() for options.
#' @param interval_to_return Time interval to be returned. 0.5 is half hourly, 1 is hourly, 12 is twice daily, 24 is daily, etc..
#' @param aggregate_time_steps If TRUE, the time steps will be averaged around the interval_to_return steps.
#'
#' @return list of results where each element of the list corresponds to a row of parameters in new_parameters
#' @export
spooky_parallel<-function(
    list_args_list=list(
      job_1=list(
        drivers=list(dr1=rTREES::ExampleDriver(ndays = 10,start_jday = 100)),
        base_parameters=ExampleParameters(),
        new_parameters=data.frame(),
        rss=ExampleRSS(),
        which_out=c(T,T,T),
        verbosity=F,
        softerror_max=5,
      )
    ),
    all_pkgs=c("rTREES"),
    run_func=rTREES::rTREES,#switch to wrapper
    n_cores=5,
    timeout_scalar=0,
    calibration_fun=NA#function(...){return(1)}
){
  n_cores<-min(n_cores,length(list_args_list))
  if(!is.function(calibration_fun)&&!is.na(calibration_fun)&&is.numeric(calibration_fun)&&calibration_fun>1){
    calibration_fun<-function(...)substitute(mx,list(mx=calibration_fun))
  }
  if(timeout_scalar>0&&n_cores>1&&is.function(calibration_fun)){
    max_time<-calibration_fun(
      list_args_list=list_args_list,
      all_pkgs=all_pkgs,
      run_func=run_func,
      n_cores=n_cores
    )*timeout_scalar
  }else if(timeout_scalar==0||n_cores==1){
    max_time<-Inf
  }else{
    stop("incorrect timeout_scalar or n_cores")
  }


  #base job object
  job_base<-list(
    job_id=NA,
    job_status="uninitialized",#uninitialized,running,finshed
    job_session=NA,#callr::r_session$new(),#This will be the callr::rsesson
    job_packages=NA,#c("rTREES"),#
    job_function=NA,#rTREES
    job_fun_args=NA,#list(
    # env_driver_in =all_drvr[[1]],
    # base_parameters = param_set[[1]],
    # root_shoot_soil = rss_set[[1]],
    # which_out = which_out,
    # verbosity = verbosity,
    # softerror_max = softerror_max
    # ),#named list of args for rTREES
    job_start_time=NA,
    job_results=NA,
    job_stdout=NA,
    job_stderr=NA,
    job_error=NA
  )

  #init job list
  job_ls<-list()
  #build job list
  job_idx<-1
  for(ar in 1:length(list_args_list)){
    temp_new_job<-job_base
    temp_new_job$job_id<-list_args_list[[ar]]$job_id
    temp_new_job$job_packages<-all_pkgs
    temp_new_job$job_function<-run_func
    temp_new_job$job_fun_args<-list_args_list[[ar]]$args
    job_ls[[ar]]<-temp_new_job
  }

  n_jobs<-length(list_args_list)
  unfinished_jobs<-T
  curr_idx<-0
  finished_count<-0
  running<-0
  first_run<-T
  reloop<-F
  progressr::handlers(global = TRUE)
  p <- progressr::progressor(steps =as.integer(n_jobs))
  while(unfinished_jobs){
    if(!first_run&&curr_idx>=n_jobs){
      curr_idx<-1
      if(running==0){
        if(reloop){
          unfinished_jobs<-F
          warning("Jobs failed to init")
        }else{
          reloop<-T
        }
      }
    }else{
      curr_idx<-curr_idx+1
      reloop<-F
    }
    first_run<-F
    finished_count<-0
    running<-0
    for(i in 1:n_jobs){
      if(
        job_ls[[i]]$job_status=="running"&&
        job_ls[[i]]$job_session$get_state()=="busy"
      ){
        running<-running+1
      }else if(job_ls[[i]]$job_status=="finished"||
               job_ls[[i]]$job_status=="timeout"){
        finished_count<-finished_count+1
      }
    }

    # print(paste("finished: ",finished_count," and running: ",running))

    if(finished_count>=n_jobs){
      unfinished_jobs<-F
    }

    if(running<n_cores&&unfinished_jobs){
      if(
        job_ls[[curr_idx]]$job_status=="uninitialized"
      ){#start a new job
        job_ls[[curr_idx]]$job_session<-callr::r_session$new()
        job_ls[[curr_idx]]$job_session$call(
          function(
    job_fun_args,
    job_packages,
    fun_in
          ){
            library(job_packages,character.only =T);
            fun_in(
              job_fun_args
            )
          },
    args =list(
      job_fun_args=job_ls[[curr_idx]]$job_fun_args,
      job_packages=job_ls[[curr_idx]]$job_packages,
      fun_in=job_ls[[curr_idx]]$job_function
    )
        )
        job_ls[[curr_idx]]$job_start_time<-Sys.time()
        job_ls[[curr_idx]]$job_status<-"running"
        # print("new job")
      }
    }
    if(#check if done
      job_ls[[curr_idx]]$job_status=="running"&&
      job_ls[[curr_idx]]$job_session$poll_process(100)=="ready"
    ){
      tempres<-job_ls[[curr_idx]]$job_session$read()
      job_ls[[curr_idx]]$job_results<-tempres$result
      job_ls[[curr_idx]]$job_stdout<-tempres$stdout
      job_ls[[curr_idx]]$job_stderr<-tempres$stderr
      job_ls[[curr_idx]]$job_error<-tempres$error
      job_ls[[curr_idx]]$job_status<-"finished"
      job_ls[[curr_idx]]$job_session$close()
      p()
      # print("fin")
    }
    if(#timeout check
      job_ls[[curr_idx]]$job_status=="running"&&
      job_ls[[curr_idx]]$job_session$poll_process(100)!="ready"&&
      difftime(Sys.time(),job_ls[[curr_idx]]$job_start_time,units = "secs")>max_time
    ){
      job_ls[[curr_idx]]$job_session$close()
      job_ls[[curr_idx]]$job_status<-"timeout"
      p()
      # print("to")
    }
  }

  return(job_ls)
}

#' Prepare inputs for spooky_parallel
#' @param base_parameters
#' @param new_parameters
#' @param drivers
#' @param rss
#' @param vars_to_return
#' @param interval_to_return
#' @param aggregate_time_steps
#' @param verbosity
#' @param softerror_max
#' @param which_out
#' @return args list for spooky_parallel
#' @export
prep_rTREES_parallel<-function(
    base_parameters=parameters,
    new_parameters,
    drivers=NA,
    rss=NA,
    vars_to_return="all",
    interval_to_return=12,
    aggregate_time_steps=FALSE,
    verbosity=FALSE,
    softerror_max=5,
    which_out
){
  #driver check
  #parameter check
  #rss check

  #build driver list
  # drvr_set<-list(
  #   dr1=ExampleDriver(ndays = 10,start_jday = 100),
  #   dr2=ExampleDriver(ndays = 10,start_jday = 200),
  #   dr3=ExampleDriver(ndays = 10,start_jday = 300),
  #   dr4=ExampleDriver(ndays = 10,start_jday = 250)
  # )
  if(depth(drivers)==1){
    drivers<-list(drivers)
  }
  ndrvrs<-length(drivers)
  if(is.null(names(drivers))){
    name_vec<-c()
    for(i in 1:ndrvrs){
      name_vec[i]<-paste0("driver-",i)
    }
    names(drivers)<-name_vec
  }
  #build parameter list
  # base_parameter_s<-ExampleParameters()
  # new_parameters<-data.frame(
  #   microbiomeScalar=runif(500,5,50),
  #   leafArea_Rate=runif(500,0.0001,0.001))
  param_set<-lapply(
    1:nrow(new_parameters),
    function(ro) {
      # list(
      parameters = rTREES::ChangeParameter(
        base_parameters,
        new_parameters[ro,,drop=FALSE],
        VERBOSE = F
      )
      # )
    }
  )
  nprms<-length(param_set)
  all_set_names<-vector()
  for(j in 1:nrow(new_parameters)){
    set_name<-c()
    for(n in 1:ncol(new_parameters)){
      set_name<-paste(set_name,paste(
        names(new_parameters)[n],
        gsub("e\\+", "*10^", format(new_parameters[j,n],scientific=T,digits=4)
        ),sep="@"
      ),sep="&"
      )
    }
    all_set_names[j]<-set_name
  }
  names(param_set)<-all_set_names
  #build rss list
  # rss_set<-list(
  #   ExampleRSS()
  # )
  if(depth(rss)==1){
    rss_set<-list(rss)
  }else{
    rss_set<-rss
  }
  nrss<-length(rss_set)
  # args_idx<-1
  named_list_of_args<-list()
  for(dr in 1:ndrvrs){
    for(rss in 1:nrss){#will add this name in the future so it will be driver::rss::param
      for(pr in 1:nprms){
        named_list_of_args[[paste(names(drivers)[dr],names(param_set)[pr],sep="::")]]<-list(
          job_id=list(driver=names(drivers)[dr],parameters=names(param_set)[pr]),
          args=list(
            env_driver_in =drivers[[dr]],
            base_parameters = param_set[[pr]],
            root_shoot_soil = rss_set[[rss]],
            which_out = which_out,
            verbosity = verbosity,
            softerror_max = softerror_max,
            vars_to_return=vars_to_return,
            interval_to_return=interval_to_return,
            aggregate_time_steps=aggregate_time_steps
          )
        )
        # args_idx<-args_idx+1
      }
    }
  }

  return(named_list_of_args)#also includes element for job_id
}

#' rTREES wrapper for spooky_parallel. This exists because spooky_parallel only takes and passes one arg.
#' @param args_in named list of rTREES inputs
#' @return cleaned and aggregated results of a single element from the args list.
#' @export
rTREES_spooky_wrapper<-function(
    args_in=list(
      base_parameters=parameters,
      env_driver_in=NA,
      root_shoot_soil=NA,
      vars_to_return="all",
      interval_to_return=12,
      aggregate_time_steps=FALSE,
      verbosity=FALSE,
      softerror_max=5
    )

){
  rtrees_results<-rTREES::rTREES(
    env_driver_in = args_in$env_driver_in, #drivers[[dr]],
    base_parameters =args_in$base_parameters,
    root_shoot_soil = args_in$root_shoot_soil,
    which_out=args_in$which_out,
    verbosity=args_in$verbosity,
    softerror_max = args_in$softerror_max
  )%>%
    rTREES::Clean_rTREES_output(
      driver=args_in$env_driver_in
    ) %>%
    rTREES::aggregate_and_filter(
      root_shoot_soil=args_in$root_shoot_soil,
      interval_to_return=args_in$interval_to_return,
      which_out=args_in$which_out,
      vars_to_return=args_in$vars_to_return,
      aggregate_time_steps=args_in$aggregate_time_steps
    )
  return(rtrees_results)
}

#' Aggregates and filters outputs of a single rTREES run
#' @param rtrees_results Results from rTREES::Clean_rTREES_output
#' @param root_shoot_soil
#' @param interval_to_return
#' @param which_out
#' @param vars_to_return
#' @param aggregate_time_steps
#' @return Aggregated and filters rTREES results
#' @export
aggregate_and_filter<-function(
    rtrees_results,
    root_shoot_soil,
    interval_to_return=48,
    which_out,
    vars_to_return,
    aggregate_time_steps=F
){
  rtrees_sim<-NA
  rtrees_hyd<-NA
  rtrees_leaf<-NA
  interval_to_return<-interval_to_return*2
  all_possible_vars<-rTREES::Possible_vars(n_layers=root_shoot_soil$rmodules)
  if(any(vars_to_return%in%"all")){
    vars_to_return<-all_possible_vars
    which_out[1:3]<-T
  }else{
    if(any(vars_to_return%in%all_possible_vars[5:which(all_possible_vars==paste0("ar",root_shoot_soil$rmodules-1))])){
      which_out[1]<-T
    }
    else{
      which_out[1]<-F
    }
    if(any(vars_to_return%in%all_possible_vars[(1+which(all_possible_vars==paste0("ar",root_shoot_soil$rmodules-1))):length(all_possible_vars)])){
      which_out[2]<-T
    }else{
      which_out[2]<-F
    }
  }
  vars_to_return<-c("year","jday","hour","min",vars_to_return)

  if(aggregate_time_steps){

    if(which_out[1]&&inherits(rtrees_results[["sim"]],"data.frame")&&!"none"%in%names(rtrees_results[["sim"]])){
      rtrees_sim<-rtrees_results[["sim"]][,] %>%
        dplyr::group_by(group = (dplyr::row_number() - 1) %/% interval_to_return) %>%
        dplyr::summarize(dplyr::across(dplyr::any_of(vars_to_return),~mean(.x,na.rm=T))) %>%
        as.data.frame()
    }
    if(which_out[2]&&inherits(rtrees_results[["hyd"]],"data.frame")&&!"none"%in%names(rtrees_results[["hyd"]])){
      rtrees_hyd<-rtrees_results[["hyd"]][,] %>%
        dplyr::group_by(group = (dplyr::row_number() - 1) %/% interval_to_return) %>%
        dplyr::summarize(dplyr::across(dplyr::any_of(vars_to_return),~mean(.x,na.rm=T))) %>%
        as.data.frame()
    }
    if(which_out[3]&&inherits(rtrees_results[["leaf"]],"data.frame")&&!"none"%in%names(rtrees_results[["leaf"]])){
      rtrees_leaf<-rtrees_results[["leaf"]][,colSums(rtrees_results[["leaf"]]) != 0] %>%
        dplyr::group_by(group = (dplyr::row_number() - 1) %/% interval_to_return) %>%
        dplyr::summarize(dplyr::across(dplyr::everything(),~mean(.x,na.rm=T))) %>%
        as.data.frame()
    }
  }else{
    if(which_out[1]&&inherits(rtrees_results[["sim"]],"data.frame")&&!"none"%in%names(rtrees_results[["sim"]])){
      rtrees_sim<-rtrees_results[["sim"]] %>%
        dplyr::select(dplyr::any_of(vars_to_return)) %>%
        dplyr::filter((dplyr::row_number()-1)%%interval_to_return==0)
    }
    if(which_out[2]&&inherits(rtrees_results[["hyd"]],"data.frame")&&!"none"%in%names(rtrees_results[["hyd"]])){
      rtrees_hyd<-rtrees_results[["hyd"]] %>%
        dplyr::select(dplyr::any_of(vars_to_return)) %>%
        dplyr::filter((dplyr::row_number()-1)%%interval_to_return==0)
    }
    if(which_out[3]&&inherits(rtrees_results[["leaf"]],"data.frame")&&!"none"%in%names(rtrees_results[["leaf"]])){
      rtrees_leaf<-rtrees_results[["leaf"]][,colSums(rtrees_results[["leaf"]]) != 0]%>%
        dplyr::filter((dplyr::row_number()-1)%%interval_to_return==0)
    }

  }
  return(list(
    sim=rtrees_sim,
    hyd=rtrees_hyd,
    leaf=rtrees_leaf
  )
  )
}

#' Timeout calibration function for spooky_parallel when using rTREES
#' @param list_args_list
#' @param all_pkgs
#' @param run_func
#' @param n_cores
#' @return time estimate for longest run out of args list
#' @export
rTREES_calib_function<-function(
    list_args_list,
    all_pkgs,
    run_func,
    n_cores
){
  message("\n\n\n*********************************************************\nBeginning calibration, ignore console until complete.\n*********************************************************\n")
  #calibrate
  lngst_dr<-list_args_list[[1]]$args$env_driver_in
  for(ld in 1:length(list_args_list)){
    if(nrow(list_args_list[[ld]]$args$env_driver_in)>nrow(lngst_dr)){
      lngst_dr<-list_args_list[[ld]]$args$env_driver_in
    }
  }
  if(nrow(lngst_dr)<6){
    tdriver<-rTREES::ExampleDriver(ndays = 20,start_jday = 200)
  }else{
    tdriver<-lngst_dr
  }
  calib_max<-nrow(tdriver)
  calib_steps<-c(
    calib_max,
    floor(calib_max*0.9),
    # floor(calib_max*0.8),#This is a very straight line, don't need ten.
    floor(calib_max*0.7),
    # floor(calib_max*0.6),
    floor(calib_max*0.5),
    # floor(calib_max*0.4),
    floor(calib_max*0.3),
    # floor(calib_max*0.2),
    floor(calib_max*0.1)
  )
  tdiff<-vector()
  for(i in 1:length(calib_steps)){
    test_args<-list()
    for(j in min(n_cores,length(list_args_list))){
      test_args[[j]]<-list_args_list[[j]]
      test_args[[j]]$args$env_driver_in<-test_args[[j]]$args$env_driver_in[1:calib_steps[i],]
    }
    t0<-Sys.time()

    spooky_parallel(
      list_args_list=test_args,
      all_pkgs=all_pkgs,
      run_func=run_func,
      timeout_scalar=0,
      n_cores = n_cores,
      calibration_fun = NA
    )
    tdiff[i]<-difftime(Sys.time(),t0,units = "secs")
  }
  coefs<-lm(tdiff~calib_steps)$coefficients
  max_time<-(coefs[1]+nrow(lngst_dr)*coefs[2])
  message("\n*********************************************************\nCalibration complete\n*********************************************************\n\n\n")
  return(max_time)
}


#' Clean up final outputs from spooky_parallel
#' @param job_ls Output of spooky_parallel when using rTREES
#' @param debug When TRUE retain information from callr run. This includes, errors, exit conditions, and more. If rTREES verbosity is also TRUE, that will be stored in the job_stdout element. Use cat() when trying to view job_stdout.
#' @return If debug is F, returns the typical rTREES parallel results. If debug is T, returns a list with typical rTREES parallel results and the full job outputs from callr.
#' @export
rTREES_par_finsh<-function(
    job_ls,
    debug=F
){
  # #
  final_results<-list()
  for(aj in 1:length(job_ls)){
    final_results[[job_ls[[aj]]$job_id$driver]][[job_ls[[aj]]$job_id$parameters]]<-job_ls[[aj]]$job_results
  }

  for(i in 1:length(job_ls)){
    job_ls[[i]]$job_session$close()
  }

  if(debug==T){
    return(
      list(
        rTREES=final_results,
        debug=job_ls
      )
    )
  }else{
    return(final_results)
  }
}

#' If any of the elements of spooky_parallel failed to complete (only visible if debug was set to T), then you can use this function to retry running only the ones that failed. You can use this to also set longer run times (actual maximum run time, not a scalar) or turn on verbosity for viewing job_stdout.
#' @param results_debug
#' @param n_cores
#' @param max_time
#' @param verbosity
#' @return cleaned adn aggregated results of a single element from the args list.
#' @export
retry_spooky<-function(
    results_debug,
    n_cores,
    max_time=0,
    verbosity=F
){

  retry_args<-list()
  retry_func<-results_debug[[1]]$job_function
  retry_pkgs<-results_debug[[1]]$job_packages
  retry_idx<-1
  orig_idx<-vector()
  for(i in 1:length(results_debug)){
    if(results_debug[[i]]$job_status!="finished"){
      retry_args[[retry_idx]]<-list()
      retry_args[[retry_idx]]$job_id<-results_debug[[i]]$job_id
      retry_args[[retry_idx]]$args<-results_debug[[i]]$job_fun_args
      retry_args[[retry_idx]]$args$verbosity<-verbosity
      retry_idx<-retry_idx+1
      orig_idx<-append(orig_idx,i)
    }
  }
  if(max_time>0){
    calib_func<-function(...)substitute(mx,list(mx=max_time))
    timeout_scalar<-1
  }else{
    calib_func<-NA
    timeout_scalar<-0
  }
  retry_results<-spooky_parallel(
    list_args_list=retry_args,
    all_pkgs=retry_pkgs,
    run_func=retry_func,
    n_cores=n_cores,
    timeout_scalar=timeout_scalar,
    calibration_fun = calib_func
  )
  for(fin in 1:length(retry_results)){
    results_debug[[orig_idx[fin]]]<-retry_results[[fin]]
  }
  return(results_debug)
}


#' rTREES parallel run
#' Takes a data frame with each column being a parameter (run ExampleParameters() to see proper names)
#' and each row is a simulation to run with those parameters and runs rTREES with those parameters. These
#' parameter sets are run in parallel and a list of run results are returned in the same order as the
#' data frame.
#' @import future
#' @import doFuture
#' @import foreach
#' @param base_parameters Initial parameters. Using Load_TREES_files() is recommended
#' @param drivers Environmental driver. Using Load_TREES_files() is recommended
#' @param root_shoot_soil Initial root_shoot_soil. Using Load_TREES_files() is recommended
#' @param new_parameters Parameters to be run. rTREES will be run over each row.
#' @param ncores The number of cores you would like jobs to be split among. It is recommended that you keep a couple cores free for your system to retain functionality while running simulations.
#' @param vars_to_return rTREES outputs you want to have returned. Using 'all' is allowed but not recommend. See Possible_vars() for options.
#' @param interval_to_return Time interval to be returned. 0.5 is half hourly, 1 is hourly, 12 is twice daily, 24 is daily, etc..
#' @param aggregate_time_steps If TRUE, the time steps will be averaged around the interval_to_return steps.
#' @param debug When TRUE retain information from callr run. This includes, errors, exit conditions, and more. If rTREES verbosity is also TRUE, that will be stored in the job_stdout element. Use cat() when trying to view job_stdout.
#'
#' @return list of results where each element of the list corresponds to a row of parameters in new_parameters
#' @export
#'
#' @examples
#' BADDLY OUTDATED
#' ExampleParameters()[,2]
#'
#' my_new_params<-data.frame(
#'    SLA_max=abs(rnorm(20,20,4)),
#'    raininNitrate=abs(rnorm(20,100,30))
#'  )
#'
#'
#'  my_par_run<-rTREES_parallel_run(
#'    base_parameters = ExampleParameters(),
#'    drivers = list(drv1= ExampleDriver(ndays=5),drv2=ExampleDriver(ndays=8,precip_amount = 0.1)),
#'    root_shoot_soil = ExampleRSS(),
#'    new_parameters = my_new_params,
#'    vars_to_return = c("waterStress","LAI","RootLat_b1","latStemK"),
#'    parallel::detectCores()-2,
#'    interval_to_return = 12
#'  )
#'
#' # Just using the internal gamma sample for leaf growth parameters (make sure your gamma dist values are correct)
#'  my_par_run_gamma<-rTREES_parallel_run(
#'    base_parameters = ExampleParameters(),
#'    drivers = list(drv1= ExampleDriver(ndays=5),drv2=ExampleDriver(ndays=8,precip_amount = 0.1)),
#'    root_shoot_soil = ExampleRSS(),
#'    new_parameters = data.frame(useLeafGamma=rep(1,10)),
#'    vars_to_return = c("waterStress","LAI","RootLat_b1","latStemK"),
#'    parallel::detectCores()-2,
#'    interval_to_return = 12
#'  )
#'
#'
rTREES_parallel_run<-function(
    base_parameters=parameters,
    drivers=driver,
    root_shoot_soil=root_shoot_soil,
    new_parameters= data.frame(
      leafAreaMax=1:10,
      leafArea_Rate=1:10,
      microbiomeScalar=1:10
    ),
    vars_to_return="all",
    ncores=future::availableCores()-2,
    interval_to_return=12,
    aggregate_time_steps=FALSE,
    verbosity=FALSE,
    softerror_max=5,
    timeout_scalar=5,
    debug=F
){

  rTREES::prep_rTREES_parallel(
    base_parameters=base_parameters,
    new_parameters=new_parameters,
    drivers=drivers,
    rss=root_shoot_soil,
    vars_to_return=vars_to_return,
    interval_to_return=interval_to_return,
    aggregate_time_steps=aggregate_time_steps,
    verbosity=verbosity,
    softerror_max=softerror_max,
    which_out=c(T,T,T)#fix this
  ) %>%
    rTREES::spooky_parallel(
      all_pkgs="rTREES",
      run_func=rTREES::rTREES_spooky_wrapper,
      n_cores=ncores,
      timeout_scalar=timeout_scalar,
      calibration_fun = rTREES::rTREES_calib_function
    ) %>%
    rTREES::rTREES_par_finish(
      debug=debug
    )
}

