unsat_zone_drainage_R <- function(
    dZ1,
    dZ2,
    pore_size_index,
    ko,
    theta1,
    theta2,
    field_capacity,
    residual,
    air_entry_pressure,
    porosity,
    mineral_fraction
) {
  if (dZ2 <= 0.0) {
    return(0.0)
  }
  if (dZ1 < 0.0001) {
    return(0.0001)
  }
  if (theta1 <= field_capacity) {
    return(0.0)
  }

  drain <- totalDrain <- 0.0
  if (theta1 > 0.9 * porosity) {
    iter <- 30
    ko <- ko / 30.0
  } else if (theta1 > 0.67 * porosity) {
    iter <- 6
    ko <- ko / 6.0
  } else if (theta1 > field_capacity) {
    iter <- 3
    ko <- ko / 3.0
  } else {
    iter <- 1
    ko <- ko / 1.0
  }

  Z1 <- 0.5 * dZ1
  Z2 <- 0.5 * (dZ1 + dZ2)

  fc <- field_capacity * dZ1 * mineral_fraction

  for (i in 1:iter) {
    suz1 <- theta1 * dZ1 * mineral_fraction
    suz2 <- theta2 * dZ2 * mineral_fraction

    n <- pore_size_index + 1.0
    m <- pore_size_index / n
    S <- (theta1 - residual) / (porosity - residual)
    if (S <= 0.001) {
      S <- 0.001
    } else if (S > 1.0) {
      S <- 1.0
    }
    ku <- ko * S ^ (0.5) * (1 - (1 - S ^ (1.0 / m)) ^ m) ^ 2.0
    psi1 <- air_entry_pressure * (S ^ (-1.0 / m) - 1) ^ (1.0 / n)
    S <- (theta2 - residual) / (porosity - residual)
    if (S <= 0.001) {
      S <- 0.001
    } else if (S > 1.0) {
      S <- 1.0
    }
    psi2 <- air_entry_pressure * (S ^ (-1.0 / m) - 1) ^ (1.0 / n)
    drain <- ku * ((psi2 - psi1) / (0.5 * (dZ1 + dZ2)) + 1.0)
    totalDrain <- totalDrain + drain
    suz1 <- suz1 - drain
    suz2 <- suz2 + drain
    theta1 <- suz1 / (dZ1 * mineral_fraction)
    theta2 <- suz2 / (dZ2 * mineral_fraction)
  }

  if (totalDrain > (suz1 - fc)) {
    totalDrain <- suz1 - fc
  }
  if (totalDrain < 0.0) {
    totalDrain <- 0.0
  }

  return(totalDrain)
}

Rcpp::cppFunction(
  code="
  double unsat_zone_drainage(
  double dZ1,
  double dZ2,
  double pore_size_index,
  double ko,
  double theta1,
  double theta2,
  double field_capacity,
  double residual,
  double air_entry_pressure,
  double porosity,
  double mineral_fraction
                           )
{
  double drain, totalDrain, ku, S, n, m, fc, suz1, suz2, psi1, psi2;
  double Z1, Z2;
  int iter;

  if (dZ2 <= 0.0)
  {
    return(0.0);
  }
  if (dZ1 < 0.0001)
  {
    return(0.0001);
  }
  if (theta1 <= field_capacity)
  {
    return(0.0);
  }

  drain = totalDrain = 0.0;
  if (theta1 > 0.9*porosity)
  {
    iter=30; //step time down as low as 100 msec
    ko = ko/30.0;

  }
  else if (theta1 > 0.67*porosity)
  {
    iter=6;
    ko = ko/6.0;
  }
  else if (theta1 > field_capacity)//This paired with the line above enforcing theta1>field_capacity else return 0.0 means that this will always be true.
   {
    iter = 3;
    ko = ko/3.0;
  }
  else//thus this is never the case.
  {
    iter = 1;
    ko = ko/1.0;
  }

  Z1 = 0.5*dZ1;
  Z2 = 0.5*(dZ1 + dZ2);

  fc = field_capacity*dZ1*mineral_fraction;//Prop
  for (int i = 0; i < iter; ++i)
  {
    //no drainage if draining layer is already at field capacity;
    suz1 = theta1*dZ1*mineral_fraction;
    suz2 = theta2*dZ2*mineral_fraction;

    //calculate hydraulic conductivity for draining soil layer
    n = pore_size_index + 1.0;
    m = pore_size_index / n;
    S = (theta1 - residual) / (porosity - residual);
    if (S <= 0.001)
    {
      S = 0.001;
    }
    else if (S > 1.0)
    {
      S = 1.0;
    }
    //ku = ko * pow(S, n) * pow(1.0 - pow(1.0 - pow(S, 1.0/m), m), 2.0);
    ku = ko * pow(S, 0.5) * pow(1.0 - pow(1.0 - pow(S, 1.0/m), m), 2.0);
    //calculate soil water potential for draining soil layer
    psi1 = air_entry_pressure*pow(pow(S,-1.0/m)-1,1.0/n);//PROP
    //calculate soil water potential for receiving soil layer
    S = (theta2 - residual) / (porosity - residual);
    if (S <= 0.001)
    {
      S = 0.001;
    }
    else if (S > 1.0)
    {
      S = 1.0;
    }
    psi2 = air_entry_pressure*pow(pow(S,-1.0/m)-1.0,1.0/n);
    //calculate drainage using Darcy's Law
    drain = ku*((psi2-psi1)/(0.5*(dZ1+dZ2))+1.0);// %%%theta %%%dz from 0.5*(dZ1+dZ2)+1.0???
    //drain = ku*((psi2-psi1)/(Z2-Z1)+1.0);
    //update total drainage and moisture contents
    totalDrain += drain;
    suz1 -= drain;
    suz2 += drain;
    theta1 = suz1/(dZ1*mineral_fraction);
    theta2 = suz2/(dZ2*mineral_fraction);
  }
  if (totalDrain > (suz1-fc))
  {
    totalDrain = suz1-fc;
  }
  if (totalDrain < 0.0)
  {
    totalDrain = 0.0;
  }


  return(totalDrain);
}
  "

)
