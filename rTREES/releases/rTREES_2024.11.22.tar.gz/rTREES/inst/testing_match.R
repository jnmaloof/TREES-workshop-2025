#* Custom tokenizer will split words greater than 3 characters and use ## to indicate they were preceded by other characters and ## to indicate they were followed by other characters.
#* everything will be to lower and only alphanumerics will be allowed.
library(tidyverse)

tiny_tokenizer<-function(text_string,token_length=3){
  alpha_num<-gsub("[^a-zA-Z0-9]", " ", tolower(text_string))
  alpha_num_single_spaced <-gsub("\\s{2,}", "", alpha_num)
  alpha_num_single_spaced_split<-strsplit(x = alpha_num_single_spaced,split = " ")
  subset_tiny_tokens<-vector()
  for(i in 1:length(alpha_num_single_spaced_split)){
    subset_split<-alpha_num_single_spaced_split[[i]]
    for(wrd in subset_split){
      if(nchar(wrd)<(token_length+1)){
        subset_tiny_tokens<-append(x = subset_tiny_tokens,values = wrd)
      }else{
        sub_wrds<-vector()
        pattern_split <- paste0('(?<=.{',token_length,'})')
        sub_wrds<-unlist(strsplit(wrd, pattern_split, perl=TRUE))
        if(length(sub_wrds)>2){
          sub_wrds[1]<-paste0(sub_wrds[1],"##")
          sub_wrds[2:(length(sub_wrds)-1)]<-paste0("##",sub_wrds[2:(length(sub_wrds)-1)],"##")
          sub_wrds[length(sub_wrds)]<-paste0("##",sub_wrds[length(sub_wrds)])
        }else{
          sub_wrds[1]<-paste0(sub_wrds[1],"##")
          sub_wrds[length(sub_wrds)]<-paste0("##",sub_wrds[length(sub_wrds)])
        }

        subset_tiny_tokens<-append(x = subset_tiny_tokens,values = sub_wrds)
      }
    }
  }
  return(subset_tiny_tokens)
}





cosine_sim<-function(text1,text2,token_length=3,relative_corpus_table=NA){
  tkns1<-tiny_tokenizer(text1,token_length = token_length)
  tkns2<-tiny_tokenizer(text2,token_length = token_length)
  jtkns<-unique(c(tkns1,tkns2))
  if(any(is.na(relative_corpus_table))){
    numer_t<-0
    denom_a<-0
    denom_b<-0
    for(i in 1:length(jtkns)){
      A_i<-(sum(jtkns[i]==tkns1) )
      B_i<-(sum(jtkns[i]==tkns2) )
      numer_t<-numer_t+(A_i*B_i)
      denom_a<-denom_a+(A_i)^2
      denom_b<-denom_b+(B_i)^2
    }
    cos_sim<-numer_t/((denom_a^(0.5))*(denom_b^(0.5)))
  }else{
    numer_t<-0
    denom_a<-0
    denom_b<-0
    freq_table<-relative_corpus_table
    for(t1 in 1:length(tkns1)){
      if(is.na(freq_table[tkns1[t1]])){freq_table[tkns1[t1]]<-0}
    }
    for(t2 in 1:length(tkns2)){
      if(is.na(freq_table[tkns2[t2]])){freq_table[tkns2[t2]]<-0}
    }
    tb1<-table(tkns1)
    tb2<-table(tkns2)
    freq_table[names(tb1)]<-freq_table[names(tb1)]+tb1
    freq_table[names(tb2)]<-freq_table[names(tb2)]+tb2

    freq_jtkns<-as.vector(freq_table[jtkns])
    for(i in 1:length(jtkns)){
      rel_f<-freq_jtkns[i]
      cur_jtkn<-jtkns[i]
      A_i<-(sum(cur_jtkn==tkns1)/rel_f)
      B_i<-(sum(cur_jtkn==tkns2)/rel_f)
      numer_t<-numer_t+(A_i*B_i)
      denom_a<-denom_a+(A_i)^2
      denom_b<-denom_b+(B_i)^2
    }
    cos_sim<-numer_t/((denom_a^(0.5))*(denom_b^(0.5)))
  }

  return(cos_sim)
}


valid_params<-rTREES::ExampleParameters() %>% mutate(combo=paste(Parameter_Name,Notes))
new_vp<-valid_params %>% mutate(score=00,id_match=0)
all_possible<-paste(new_vp$Parameter_Name,new_vp$combo,collapse = " ")
tkn_length<-3
all_possible_table<-table(tiny_tokenizer(all_possible,token_length = tkn_length))
for(comp in 1:nrow(new_vp)){
  scores<-vector()
  for(sc in 1:nrow(new_vp)){
    scores<-append(
      scores,
      abs(
        1-cosine_sim(
          new_vp[comp,"Parameter_Name"],
          new_vp[sc,"combo"],
          tkn_length,
          relative_corpus_table =all_possible_table
        )
      )
    )
  }
  new_vp[comp,"id_match"]<-which.min(scores)
  new_vp[comp,"score"]<-min(scores)
}
new_vp<-new_vp %>%
  dplyr::mutate(dups=(duplicated(id_match)|duplicated(id_match,fromLast = T))) %>%
  dplyr::mutate(weak=ifelse(score>0.8,T,F))
dups_names<-new_vp[new_vp$dups,"Parameter_Name"]
weak_names<-new_vp[new_vp$weak,"Parameter_Name"]
warning(paste("The following parameters had duplicate assignments or weak matches and need manual repairs:\n","\n>Duplicates:\n",paste("\t",dups_names,collapse = "\n"),"\n\n>Weak matches:\n",paste("\t",weak_names,collapse="\n")))





#
# match_score<-function(text1,text2){
#   tkns1<-tiny_tokenizer(text1)
#   tkns2<-tiny_tokenizer(text2)
#   return(
#     max(sum(tkns1%in%tkns2),sum(tkns2%in%tkns1))
#     # /max(sum(nchar(text1)),sum(nchar(text2)))
#
#     )
# }


#### Old  param repari
# real_params <- real_params %>%
#   dplyr::mutate(
#     combo = paste(trimws(Parameter_Name),trimws(Notes))
#     )
# par_match <-stringdist::stringdistmatrix(
#   params_in$Notes, real_params$combo, method = "cosine"
# )
# taken_match <-params_in %>%
#   dplyr::mutate(curr_take_idx = NA, curr_take_score = 99999)
#
# for (i in 1:ncol(par_match)) {
#   taken_match[i, "curr_take_idx"] <- which.min(par_match[, i])
#   taken_match[i, "curr_take_score"] <-
#     par_match[taken_match[i, "curr_take_idx"], i]
#
# }
#
#
# taken_match <- taken_match %>%
#   dplyr::mutate(dup = (
#     duplicated(curr_take_idx) | duplicated(curr_take_idx, fromLast = T)
#   ))
#
# for (i in 1:nrow(taken_match)) {
#   if (taken_match[i, "dup"]) {
#     dup_idx <-
#       which(taken_match[, "curr_take_idx"] == taken_match[i, "curr_take_idx"])
#
#     best_idx <-
#       dup_idx[which.min(taken_match[dup_idx, "curr_take_score"])]
#     for (j in dup_idx) {
#       if (j != best_idx) {
#         taken_match[j, "curr_take_idx"] <- NA
#         taken_match[j, "curr_take_score"] <- NA
#         taken_match[j, "dup"] <- FALSE
#       }
#     }
#   }
# }
#
#
# clean_param <- real_params %>%
#   dplyr::mutate(Value = 999999999, "InputName" = NA)
#
# for (i in 1:nrow(taken_match)) {
#   if (!is.na(taken_match[i, "curr_take_idx"])) {
#     clean_param[taken_match[i, "curr_take_idx"], "Value"] <-
#       taken_match[i, "Value"]
#     clean_param[taken_match[i, "curr_take_idx"], "InputName"] <-
#       taken_match[i, "Notes"]
#   }
#
# }
#
# check_match <- clean_param[, c("InputName", "combo")]
#
# unres<-c("The following inputs require manual intervention:")
# for (i in 1:nrow(check_match)) {
#   if (is.na(check_match[i, 1])) {
#     unres<-c(unres,(clean_param[i, "Parameter_Name"]))
#   }
# }
# if(length(unres>1)){
#   warning(paste(unres,sep="\n",collapse = "\n"))
# }
# return(list(clean_param,length(unres)-1))
# }
