library(rTREES)
library(tictoc)
library(tidyverse)
options(scipen=99999)


# # df_test<-data.table::fread("inst/FP_ex/FP_driver.txt",data.table = F)
# # ex_driver<-ExampleDriver(precip_amount = 100,start_jday =300,precipdays = 300:305,ndays=5)
# test<-ExampleParameters()
test_fp<-Load_TREES_files(
  # driver="inst/FP_ex/FP_driver.txt",
  # parameters = "inst/FP_ex/FP_parameter.p",
  # ,root_shoot_soil = "inst/FP_ex/FP_param_mod"
  driver="~/paper_share/Research_Web_Log/main_site/.data/FP_Static/FP_Driver_EX.txt",
  parameters = "~/paper_share/Research_Web_Log/main_site/.data/FP_Static/FP_parameter.p",
  ,root_shoot_soil = "~/paper_share/Research_Web_Log/main_site/.data/FP_Static/FP_param_mod"
)
#The demo files are borked. Will investigate.
#With version=1 I get reasonable results HOWEVER it looks like my ??? what showing up in the old version too! Will check if this is an issue. Pushing fixes to codeberg.

par_test<-rTREES_parallel_run(
  base_parameters = test_fp$parameters,
  drivers=test_fp$driver,
  root_shoot_soil = test_fp$root_shoot_soil,
  new_parameters = data.frame(
    leafArea_Rate=0.0009,#rnorm(6,0.000689,sd = 0.0005),#c(0.000689,0.000689*2,0.000689*1.5,0.000689*0.5),
    # projectedArea_init=6,
    initialLeafSize=0.11,
    leafAreaMax=25
    ),
  vars_to_return = "leaf",
  interval_to_return = 0.5,
  aggregate_time_steps = F,
  verbosity =F,
  ncores = 6,
  softerror_max = 5,
  timeout_scalar = 0,
  debug = T
)

tic()
par_test<-rTREES_parallel_run(
  base_parameters = test_fp$parameters,
  drivers=test_fp$driver[1:3,],
  root_shoot_soil = test_fp$root_shoot_soil,
  new_parameters = data.frame(
    leafArea_Rate=rnorm(6,0.000689,sd = 0.0005),#c(0.000689,0.000689*2,0.000689*1.5,0.000689*0.5),
    projectedArea_init=6,
    initialLeafSize=0.11,
    leafAreaMax=25

  ),
  vars_to_return = "leaf",interval_to_return = 0.5,aggregate_time_steps = F,verbosity =F
)
toc()
# 7.201 sec elapsed
tic()
par_test<-rTREES_parallel_run(
  base_parameters = test_fp$parameters,
  drivers=test_fp$driver[1:10,],
  root_shoot_soil = test_fp$root_shoot_soil,
  new_parameters = data.frame(
    leafArea_Rate=rnorm(6,0.000689,sd = 0.0005),#c(0.000689,0.000689*2,0.000689*1.5,0.000689*0.5),
    projectedArea_init=6,
    initialLeafSize=0.11,
    leafAreaMax=25

  ),
  vars_to_return = "leaf",interval_to_return = 0.5,aggregate_time_steps = F,verbosity =F
)
toc()
# 7.552 sec elapsed
tic()
par_test<-rTREES_parallel_run(
  base_parameters = test_fp$parameters,
  drivers=test_fp$driver[1:50,],
  root_shoot_soil = test_fp$root_shoot_soil,
  new_parameters = data.frame(
    leafArea_Rate=rnorm(6,0.000689,sd = 0.0005),#c(0.000689,0.000689*2,0.000689*1.5,0.000689*0.5),
    projectedArea_init=6,
    initialLeafSize=0.11,
    leafAreaMax=25

  ),
  vars_to_return = "leaf",interval_to_return = 0.5,aggregate_time_steps = F,verbosity =F
)
toc()
# 8.493 sec elapsed
tic()
par_test<-rTREES_parallel_run(
  base_parameters = test_fp$parameters,
  drivers=test_fp$driver[1:100,],
  root_shoot_soil = test_fp$root_shoot_soil,
  new_parameters = data.frame(
    leafArea_Rate=rnorm(6,0.000689,sd = 0.0005),#c(0.000689,0.000689*2,0.000689*1.5,0.000689*0.5),
    projectedArea_init=6,
    initialLeafSize=0.11,
    leafAreaMax=25

  ),
  vars_to_return = "leaf",interval_to_return = 0.5,aggregate_time_steps = F,verbosity =F
)
toc()
# 9.69 sec elapsed

tic()
par_test<-rTREES_parallel_run(
  base_parameters = test_fp$parameters,
  drivers=test_fp$driver[1:300,],
  root_shoot_soil = test_fp$root_shoot_soil,
  new_parameters = data.frame(
    leafArea_Rate=rnorm(6,0.000689,sd = 0.0005),#c(0.000689,0.000689*2,0.000689*1.5,0.000689*0.5),
    projectedArea_init=6,
    initialLeafSize=0.11,
    leafAreaMax=25

  ),
  vars_to_return = "leaf",interval_to_return = 0.5,aggregate_time_steps = F,verbosity =F
)
toc()
#13.489 sec elapsed
tic()
par_test<-rTREES_parallel_run(
  base_parameters = test_fp$parameters,
  drivers=test_fp$driver[1:600,],
  root_shoot_soil = test_fp$root_shoot_soil,
  new_parameters = data.frame(
    leafArea_Rate=rnorm(6,0.000689,sd = 0.0005),#c(0.000689,0.000689*2,0.000689*1.5,0.000689*0.5),
    projectedArea_init=6,
    initialLeafSize=0.11,
    leafAreaMax=25

  ),
  vars_to_return = "all",interval_to_return = 0.5,aggregate_time_steps = F,verbosity =F
)
toc()
#19.075 sec elapsed
nts<-c(5,10,50,100,300,600)
ttaken<-c(7.201,7.552,8.493,9.69,13.489,19.075)
plot(lm(ttaken~nts))
lm(ttaken~nts)
ggplot()+
  geom_point(aes(x=nts,y=ttaken))+
  geom_smooth(aes(x=nts,y=ttaken),method = "lm")
# withCallingHandlers({
#   setTimeLimit(360)
#   # your function goes here, runs for 360 seconds, or fails
# },
# error = function(e) {
#   # do stuff to capture error messages here
# }


timeout_calibration<-function(driver,parameters,rss){
  message("Begining calibration, ignore print out until complete.")
  ncores<-future::availableCores()-2
  all_toc<-vector()
  calib_max<-nrow(driver)
  calib_steps<-c(
    calib_max,
    floor(calib_max*0.9),
    floor(calib_max*0.8),
    floor(calib_max*0.7),
    floor(calib_max*0.6),
    floor(calib_max*0.5),
    floor(calib_max*0.4),
    floor(calib_max*0.3),
    floor(calib_max*0.2),
    floor(calib_max*0.1)
  )
  if(any(calib_steps<3)){
    calib_steps[which(calib_steps<3)]<-rep(3,sum(which(calib_steps<3)))
  }
  for(i in 1:10){
    tic()
    temp_dr<-driver[1:calib_steps[i],]
    dump<-rTREES_parallel_run(
      base_parameters = parameters,
      drivers=temp_dr,
      root_shoot_soil = rss,
      new_parameters = data.frame(
        altitude=rnorm(ncores,parameters[1,1],parameters[1,1]*0.25)
      ),
      vars_to_return = "all",
      interval_to_return = 0.5,
      aggregate_time_steps = F,
      verbosity =F
    )
    temptoc=toc()
    all_toc[i]=temptoc$toc-temptoc$tic
}
  coefs<-lm(all_toc~calib_steps)
  return(as.vector(coefs$coefficients))
}

timeout_calibration(test_fp$driver,test_fp$parameters,test_fp$root_shoot_soil)
# withCallingHandlers({
#   setTimeLimit(360)
#   # your function goes here, runs for 360 seconds, or fails
# },
# error = function(e) {
#   # do stuff to capture error messages here
# }

tic()
par_test<-rTREES_parallel_run(
  base_parameters = test_fp$parameters,
  drivers=test_fp$driver[1:30,],
  root_shoot_soil = test_fp$root_shoot_soil,
  new_parameters = data.frame(
    leafArea_Rate=rnorm(6,0.000689,sd = 0.0005),#c(0.000689,0.000689*2,0.000689*1.5,0.000689*0.5),
    projectedArea_init=6,
    initialLeafSize=0.11,
    leafAreaMax=25

  ),
  vars_to_return = "all",interval_to_return = 0.5,aggregate_time_steps = F,verbosity =F
)
toc()



#
# par_test<-rTREES_parallel_run(
#   base_parameters = test_fp$parameters,
#   drivers=test_fp$driver,
#   root_shoot_soil = test_fp$root_shoot_soil,
#   new_parameters = data.frame(lai=c(0.01,0.05,0.1,0.3,0.5)),
#   vars_to_return = "leaf",interval_to_return = 0.5,aggregate_time_steps = F,verbosity =F,version=1
# )
#
#
# par_test[["dr_1"]][[1]][["leaf"]][["Area_Leaf_1"]]
# par_test[["dr_1"]][[2]][["leaf"]][["Area_Leaf_1"]]
# par_test[["dr_1"]][[3]][["leaf"]][["Area_Leaf_1"]]
# par_test[["dr_1"]][[4]][["leaf"]][["Area_Leaf_1"]]
# par_test[["dr_1"]][[5]][["leaf"]][["Area_Leaf_1"]]
# tic()
# example_run2 <-rTREES(
#   env_driver_in  =test_fp$driver,
#   base_parameters = test_fp$parameters %>% ChangeParameter(NewValues = data.frame(projectedArea_init=1,lai=0.3,Cbelowground=79200*2)),
#   root_shoot_soil = test_fp$root_shoot_soil,
#   which_out = c(T,T,T),verbosity = T,
#   version =1
# )
#
# rTREES_cleaned_ex<-Clean_rTREES_output(
#   rTREES_output = example_run2,
#   driver = test_fp$driver
# )
# rTREES_cleaned_ex[["leaf"]][["Area_Leaf_1"]]
# toc()
# #24.915 sec elapsed o2
# #20.18 sec elapsed o3
# #19.426 sec elapsed
#
# #without output
# #6.124 sec elapsed!!!!
#
#
# # 31.89 sec elapsed
#
#
#
# #Test parallel
# # par_test<-rTREES_parallel_run(
# #   base_parameters = test_fp$parameters,
# #   drivers=data.frame(this="yop",ttsat=2),
# #   root_shoot_soil = test_fp$root_shoot_soil,
# #   new_parameters = data.frame(initial_conductivity_root=12,initial_conductivity_shoot=20,midday_at_sat_kl=-1.9),
# #   vars_to_return = "soilPsi0",interval_to_return = 12,aggregate_time_steps = F,verbosity =T
# # )
#
# names(par_test[[1]][[1]]$sim)
# names(example_run2$sim_out)[which(!names(example_run2$sim_out)%in%names(par_test[[1]][[1]]$sim))]
# #
# # names(par_test[[1]][[1]]$sim)[which(!names(par_test[[1]][[1]]$sim)%in%names(example_run2$sim_out))]
# test_fp<-Load_TREES_files(
#   # driver="inst/FP_ex/FP_driver.txt",
#   # parameters = "inst/FP_ex/FP_parameter.p",
#   # ,root_shoot_soil = "inst/FP_ex/FP_param_mod"
#   driver="/home/seedfire/Downloads/gregs_files/CMCC_585_Duke_2090.txt",
#   parameters = "/home/seedfire/Downloads/dohyoungs_files/missingoutputsinrtreesparallelrun/PARAM_Aspen_fred.p",
#   ,root_shoot_soil = "/home/seedfire/Downloads/dohyoungs_files/missingoutputsinrtreesparallelrun/param_mod"
# )
# test_fp$root_shoot_soil %>% str()
#
#
# example_run2 <-rTREES(
#   env_driver_in  =test_fp$driver,
#   base_parameters = test_fp$parameters %>% ChangeParameter(NewValues = data.frame(projectedArea_init=5,initialLeafSize=0.4)),
#   root_shoot_soil = test_fp$root_shoot_soil,
#   which_out = c(T,T,T),verbosity = T,
#   version =1
# )
#
# ChangeRootShootParams(root_shoot_soil = )
#
#
#
# test_fp_sc<-Load_TREES_files(
#   driver="~/paper_share/Research_Web_Log/main_site/.data/FP_Static/FP_Driver_EX.txt",
#   parameters = "/home/seedfire/Downloads/FP_parameter_sc.p",
#   ,root_shoot_soil = "/home/seedfire/Downloads/FP_param_mod_sc_2"
# )
#
#
# ex_sc<-rTREES(
#   env_driver_in  =test_fp_sc$driver,
#   base_parameters = test_fp_sc$parameters %>% ChangeParameter(
#     NewValues = data.frame(
#       initialLeafSize=0.11,
#       leafAreaMax=25 ,
#       projectedArea_init=0.1375,
#       # leafArea_Rate=0.000689000000*2#,
#       Cbelowground=79200*2
#       )
#     ),
#   root_shoot_soil = test_fp_sc$root_shoot_soil,
#   which_out = c(T,T,T),verbosity = T,
#   version =1
# )
# ex_sc_cln<-Clean_rTREES_output(
#   rTREES_output = ex_sc,
#   driver = test_fp_sc$driver
# )
# ex_sc_cln[["leaf"]][["Area_Leaf_1"]]
#
# library(caracas)
# 0.11=0.8*x
# x <- symbol('x')
#
# solve_sys(0.2*x-0.07112, x)
#
#
# test_fp_sc$parameters %>% filter(Parameter_Name=="SLA_max")
#
#
# 1.0/(400*8.0)*5;
#
# # axial stem length x lateral stem length = sum root axial lengths x first root layer lateral length b/c canopy_cover goal is 1
# test_fp_sc$root_shoot_soil$dslat*test_fp_sc$root_shoot_soil$dsax
# sum(test_fp$root_shoot_soil$drax)*test_fp$root_shoot_soil$drlat[1]
# 0.2*X-0.07112
#
#
# test_fp_2<-test_fp
# test_fp_2$root_shoot_soil$dslat<-0.3556
#
# example_run3 <-rTREES(
#   env_driver_in  =test_fp$driver,
#   base_parameters = test_fp_sc$parameters %>% ChangeParameter(
#     NewValues = data.frame(
#       initialLeafSize=0.11,
#       leafAreaMax=15 ,
#       projectedArea_init=5,
#       Cbelowground=79200,
#       litter_store = 0.0001,
#       litter_capacity = 0.0001
#     )
#   ),
#   root_shoot_soil = test_fp_2$root_shoot_soil,
#   which_out = c(T,T,T),verbosity = T,
#   version =3
# )
# example_run3_CL2<-Clean_rTREES_output(
#   rTREES_output = example_run3,
#   driver = test_fp_sc$driver
# )
# example_run3_CL1[["leaf"]][["Area_Leaf_1"]]
# example_run3_CL2[["leaf"]][["Area_Leaf_1"]]
#
# if (!dir.exists("~/Downloads/working_inputs")) {dir.create("~/Downloads/working_inputs")}
# Write_TREES_files(destination = "~/Downloads/working_inputs",prefix = "FP_working",driver =test_fp$driver,parameter =test_fp_sc$parameters %>% ChangeParameter(
#   NewValues = data.frame(
#     initialLeafSize=0.11,
#     leafAreaMax=15 ,
#     projectedArea_init=5,
#     Cbelowground=79200,
#
#     litter_store = 0.0001,
#     litter_capacity =  0.00008
#   ) ),rss = test_fp_2$root_shoot_soil )
#
#

# better_fp<-Load_TREES_files(
#   driver="~/Downloads/working_inputs/FP_working_driver.txt",
#   parameters = "~/Downloads/working_inputs/FP_working_parameter.p",
#   ,root_shoot_soil = "~/Downloads/working_inputs/FP_working_root_shoot_soil"
# )
# better_fp$root_shoot_soil<-test_fp$root_shoot_soil
# better_fp$root_shoot_soil$dslat<-0.3556
#
# Write_TREES_files(destination = "~/Downloads/working_inputs",prefix = "FP_working",driver =better_fp$driver,parameter =better_fp$parameters,rss = better_fp$root_shoot_soil )

library(tidyverse)
library(tictoc)
library(rTREES)
options(scipen = 9999)

better_fp<-Load_TREES_files(
  driver="~/Downloads/working_inputs/FP_working_driver.txt",
  parameters = "~/Downloads/working_inputs/FP_working_parameter.p",
  ,root_shoot_soil = "~/Downloads/working_inputs/FP_working_root_shoot_soil"
)
bedder_fp<-Load_TREES_files(
  driver="~/Downloads/working_inputs/bad/c_driver.txt",
  parameters = "~/Downloads/working_inputs/bad/c_parameter.p",
  root_shoot_soil = "~/Downloads/working_inputs/bad/c_root_shoot_soil"
)

# better_fp$parameters<-better_fp$parameters %>% ChangeParameter(
#   NewValues = data.frame(
#     litter_capacity=0.00008,
#     Croot_frac=0.00008,
#     Croot_coarse_frac=0.00008,
#     leafAreaMax=15,
#     microbiomeScalar=20
#   )
# )
# BiogeochemicalCycles::updateRootCarbonNitrogenPools():
rTREES(
  env_driver_in  =better_fp$driver,
  base_parameters = better_fp$parameters %>%
    ChangeParameter(data.frame(
      leafAreaMax=35,
      leafArea_Rate=0.0009,
      microbiomeScalar=15
    )),
  root_shoot_soil = better_fp$root_shoot_soil,
  which_out = c(T,T,T),verbosity = F,softerror_max = 1
)[["lfa_out"]][["Area_Leaf_1"]][864]



test_rss<-bedder_fp$root_shoot_soil
test_rss$layer_clay_fraction<-c(0.2,0.2,0.2,0.2)*1.5
test_rss$layer_sand_fraction<-rep(0.45,4)
rTREES(
  env_driver_in  =bedder_fp$driver,
  base_parameters = bedder_fp$parameters %>%
    ChangeParameter(data.frame(
      leafAreaMax=35,
      leafArea_Rate=0.0009,
      microbiomeScalar=15
    )),
  root_shoot_soil = test_rss ,
  which_out = c(T,T,T),verbosity = F,softerror_max = 1
)[["lfa_out"]][["Area_Leaf_1"]][864]



par_test<-rTREES_parallel_run(
  base_parameters = better_fp$parameters,
  drivers=better_fp$driver ,
  root_shoot_soil = better_fp$root_shoot_soil,
  new_parameters = data.frame(
    leafArea_Rate=0.0009,#c(0.000689,0.000689*2,0.000689*1.5,0.000689*0.5),
    leafAreaMax=35,
    microbiomeScalar=c(5,10,15,20,25,30,35)

  ),
  vars_to_return = "leaf",interval_to_return = 0.5,aggregate_time_steps = F,verbosity =F,ncores = 6,softerror_max = 4,timeout_scalar = 0,debug = F
)

best_run <-rTREES(
  env_driver_in  =better_fp$driver,
  base_parameters = better_fp$parameters %>%
    ChangeParameter(data.frame(
      leafAreaMax=40,
      leafArea_Rate=0.000689000000,
      microbiomeScalar=100
      )),
  root_shoot_soil = better_fp$root_shoot_soil,
  which_out = c(T,T,T),verbosity = F,softerror_max = 1
)
View(ExampleParameters())
better_fp$root_shoot_soil$layer_initial_water_content<-c(0.0001,0.00001,0.01,0.01)
better_fp$root_shoot_soil$layer_residual_water_content<-c(0.00001,0.02,0.02,0.5)
better_fp$root_shoot_soil$layer_sand_fraction<-c(0.2,0.3,0.3,0.3)
better_fp$root_shoot_soil$layer_clay_fraction

breakit<-better_fp$driver[1:10,,drop=F] %>%
  dplyr::mutate(
    precip=c(0,0,0,0,0,0,0,0,0
             ,0)
                )

best_run <-rTREES(
  env_driver_in  =breakit,
  base_parameters = better_fp$parameters %>%ChangeParameter(data.frame(leafAreaMax=20)),
  root_shoot_soil = better_fp$root_shoot_soil,
  which_out = c(T,T,T),verbosity = F,softerror_max = 1
)

# :rd1:0.0289:rd2:0.02:pidx:0.410425:ko:3.09683e-06:ut:0.299969:ts2:0.3:fc:0.218117:rd:0.12:cf:4.96597:p:0.3:mf:0.97
#Not adding up
#1.14338e-07
#0.000340073
unsat_zone_drainage( 0.0289,0.02,0.410425,3.09683e-06,0.299969,0.3,0.218117,0.12,4.96597,0.3,0.97)



library(tidyverse)
library(tictoc)
library(rTREES)
options(scipen = 9999)
test_fp<-Load_TREES_files(
  driver="/home/seedfire/Downloads/dohyoungs_files/missingoutputsinrtreesparallelrun/drivers_Multispe_DD_Aspen.txt",
  parameters = "/home/seedfire/Downloads/dohyoungs_files/missingoutputsinrtreesparallelrun/PARAM_Aspen_fred.p",
  root_shoot_soil = "/home/seedfire/Downloads/dohyoungs_files/missingoutputsinrtreesparallelrun/param_mod"
)

# breakit<-test_fp$driver[1:10,,drop=F] %>%
#   dplyr::mutate(
#     precip=c(0,0,0,0,0,0,0,0,0,0)
#   )
# better_fp$root_shoot_soil$layer_porosity<-c(0.4,0.4,0.4,0.4)
#

best_run <-rTREES(
  env_driver_in  =test_fp$driver,
  base_parameters = test_fp$parameters %>%ChangeParameter(data.frame(leafAreaMax=20)),
  root_shoot_soil = test_fp$root_shoot_soil,
  which_out = c(T,T,T),verbosity = F,softerror_max = 100
)



# 0.00120093
unsat_zone_drainage(
  dZ1 =
    0.048,
  dZ2 =
    0.0048,
  pore_size_index =
    0.3,
  ko =
    5.2189e-03,
  theta1 =
    2,
  theta2 =
    10,
  field_capacity =
    0.001,
  residual =
    0.000001,
  air_entry_pressure =
    0.1,
  porosity =
    0.2,
  mineral_fraction =
    0.1
)

# rootDepth[i],
# rootDepth[i+1],
# pore_size_index,
# ks/kinter,// k_theta???
#   updatedTheta,
# thetaSoil[i+1],
# field_capacity,
# residual,
# capFringe,
# porosity,
# mineral_fraction

0.5*(5.2189e-07)*0.322094*(min(0.048,0.048))
0.5*(5.2189e-07)*0.207708*(48000000)

(5.2189e-05)/0.322094*30/(0.024)


unsat_zone_drainage_cpp(
  0.048,
  0.048,
  0.322119,
  5.2189e-07,
  0.322094,
  0.207708,
  0.181942,
  0.03,
  4.96597,
  0.35,
  0.97
)

# ttl drain 0.00119968


#0.001325444

#3.4042e-19
unsat_zone_drainage(
  #:rd1:
  0.016,
  #:rd2:
  0.024,
  #:pidx:
  0.322119,
  #:ko:
  1.56567e-05,
  #:ut:
  0.349793,
  #:ts2:
  0.349884,
  #:fc:
  0.181942,
  #:rd:
  0.03,
  #:cf:
  4.96597,
  #:p:
  0.35,
  #:mf:
  0.97
)
# 0.000000004972609







# #For single runs
# if(any(results$sim_out$year==0)){
#   print(paste("Simulation stopped at step",min(which(results$sim_out$year==0))))
# }
# ### OR ###
#
# #For parallel runs
# for(dr in 1:length(parallel_results)){
#   for(rs in 1:length(parallel_results[[dr]])){
#     if(any(parallel_results[[dr]][[rs]]$sim_out$year==0)){
#       print(
#         paste(
#           "Simulation",
#           names(parallel_results)[dr],
#           names(parallel_results[[dr]])[rs],
#           "stopped at step",
#           min(
#             which(parallel_results[[dr]][[rs]]$sim_out$year==0)
#               )
#           )
#         )
#     }
#   }
# }


`#6.47
#5.9
best_run_clean<-Clean_rTREES_output(
  rTREES_output = best_run,
  driver = better_fp$driver
)
best_run_clean[["leaf"]][["Area_Leaf_1"]]
best_run_clean$sim$RLA


better_fp$parameters<-better_fp$parameters %>% ChangeParameter(
  NewValues = data.frame(
    litter_capacity=0.00008,
    Croot_frac=0.00008,
    Croot_coarse_frac=0.00008,
    leafAreaMax=15,
    microbiomeScalar=100
  )
  )
prepl

par_best<-rTREES_parallel_run(
  base_parameters = better_fp$parameters,
  drivers=better_fp$driver,
  root_shoot_soil = better_fp$root_shoot_soil,
  new_parameters = data.frame(microbiomeScalar=seq(10,1000,10)),#data.frame(leafAreaMax=c(200,100))
  vars_to_return = "leaf",
  ncores = 7,
  interval_to_return = 24,
  aggregate_time_steps = F,
  verbosity =F
)
# %>%
  #   dplyr::mutate(datetime=as.POSIXct(x = paste(year,jday,hour,min(min*100,1)*30,sep = "-"),format="%Y-%j-%H-%M"))

#Time series plots

best_long<-long_df_leaf_parallel(par_res =par_best)

best_long_spl<-best_long %>%
  tidyr::separate_wider_delim(parameter,delim =  "\n", names = c("pname", "pval")) %>%
  dplyr::mutate(pval = map_dbl(pval, ~ eval(parse(text = .x))))

ggplot(data = best_long_spl)+
  geom_point(aes(x=UTC_date_time,y = (leaf_area),color=pval))+
  theme_bw()+
  scale_colour_viridis_c()


###This si working great where increasing the microbiome just helps growth with shrinking returns
#### added a softerror check to rTREES. need to test it and give parallel run the ability to check for errors in the output by seeing if all the outputs have the same length as the input driver

ExampleDriver(ndays = 10,start_jday = 300,precipdays = c(11,15,19),precip_amount = 6)


just_examp<-rTREES(
  env_driver_in = ExampleDriver(ndays = 10,start_jday = 300,precipdays = c(11),precip_amount = 6),
  base_parameters=ExampleParameters(),
  root_shoot_soil=ExampleRSS(),
  which_out = c(T,T,T),
  verbosity = T,
  softerror_max = 5
)
